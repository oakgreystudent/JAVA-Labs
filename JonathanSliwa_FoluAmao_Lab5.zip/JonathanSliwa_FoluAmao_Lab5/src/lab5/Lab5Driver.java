package lab5;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab5Driver {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.print("Enter name of real estate file: ");
        String fileName = input.nextLine();
        input.close();

        try {
            PropertyFinder finder = new PropertyFinder(fileName);
            finder.printProperties();
        } 
        catch (FileNotFoundException ex) {
            System.out.println(ex);
        }
    }
}
